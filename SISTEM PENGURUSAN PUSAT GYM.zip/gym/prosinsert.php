
<?php
include('config.php');


$namaahli=$_POST['namaahli'];
$jenisahli=$_POST['jenisahli'];



$query="insert into ahli_gym set namaahli='$namaahli', jenisahli='$jenisahli'";
if (mysql_query($query)){
	
header ("location:data.php");
}
	else
	echo "something went wrong";
?>